# Large Scale dev pack, 24 September 2026

Start with session-2026-09-24.md, then HANDOVER.md. The full conversation is conversation-2026-09-24.md. CLAUDE.md is the project instructions file as it stood at the end of the session, and plans/ holds both milestone plans.
