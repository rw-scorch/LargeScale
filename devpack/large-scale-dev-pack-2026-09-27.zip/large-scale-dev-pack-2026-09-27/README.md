# Large Scale dev pack, 27 September 2026

Start with session-2026-09-27.md, then CLAUDE.md, which holds the project state and open items. HANDOVER.md is the kit's handover. The full conversation is conversation-2026-09-27.md, and plans/ holds the four milestone plans.
